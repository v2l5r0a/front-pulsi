export const PATHS = {
  HOME: '/',
  COWS: '/person',
  LOGIN: '/login',
  USERS: '/users'
}
